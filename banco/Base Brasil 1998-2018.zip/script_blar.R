#######################################################################
########################### SCRIPT BLAR ###############################
#######################################################################

# Paper: "Party System Change from a Multilevel Perspective: The case of Brazil (2002-2018)
# Autores: Jayane Maia, Thaís Cavalcante Martins, Pedro Costa e Matheus Henning
# Em resposta aos pareceristas do Bulletin of Latin American Research

# Todos os direitos reservados aos autores. Favor, não circular.

###################### O script #######################################

# preâmbulo

load("~/env_eda_lasa.RData")

library("tidyverse") # pacotes para tratamento de dados e plots
library("ggpubr")

`%notin%` <- Negate(`%in%`)

party_labels <- c("Others", "PSDB", "PSL", "PT")
party_labels2 <- c("PFL/DEM", "PMDB", "PSDB", "PSL", "PT")
party_losers <- c("PPS", "PFL/DEM", "PMDB", "PSDB", "PT")
party_winners <- c("PSC", "PL/PR", "PP", "PSL", "NOVO")
colors <- c("#FFD700", "#0000FF", "#808000", "#FF0000")
lineplot_colors <- c("#FF8C00", "#FFD700", "#0000FF", "#808000", "#FF0000")
colors_losers <- c("#800000", "#FF8C00", "#FFD700", "#0000FF", "#FF0000")
colors_winners <- c("#00FFFF", "#A0522D", "#FF00FF", "#808000", "#FFA500")
code_losers <- c("BRP03", "BRP04", "BRP05", "BRP19", "BRP21")
code_winners <- c("BRP01", "BRP10", "BRP13", "BRP20", "BR06")
code_party_labels2 <- c("BRP04", "BRP05", "BRP19", "BRP20", "BRP21")

# 1.0 Calculando séries temporais com a proporção de votos dos quatro partidos mais relevantes

# 1.1 Eleições para o Executivo Federal (Presidente da República)
# Analisando apenas os seguintes partidos: PT, PSDB, PSL e a soma de todos os outros partidos 

str(exe_br)
exe_br[order(exe_br$vote_share, decreasing = TRUE),]

df_plot_exe_br1 <- exe_br %>% 
  group_by(election) %>% 
  filter(party %notin% c("BRP19", "BRP20", "BRP21")) %>% 
  summarise(vote_share = sum(vote_share, na.rm = TRUE)) %>% 
  mutate(party = factor("BRP00"))

df_plot_exe_br2 <- exe_br %>% 
  filter(party %in% c("BRP19", "BRP20", "BRP21"))

df_plot_exe_br2 <- df_plot_exe_br2[,c("election", "vote_share", "party")]

df_plot_exe_br <- rbind(df_plot_exe_br1, df_plot_exe_br2)

rm(df_plot_exe_br1, df_plot_exe_br2)

plot10 <- df_plot_exe_br %>% 
  ggplot(aes(x = election, y = vote_share, color = party)) + geom_line(size = 1) + geom_point(size = 2) + 
  my_theme + 
  theme(panel.grid = element_blank(), plot.title = element_text(size = 14, face = "bold")) + 
  scale_x_continuous(breaks = c(1998, 2002, 2006, 2010, 2014, 2018)) + 
  scale_y_continuous(limits = c(0, 60), breaks = c(0, 10, 20, 30, 40, 50, 60)) + 
  scale_color_manual(name = "Party", labels = party_labels, values = colors) + 
  geom_hline(yintercept = 50, linetype = "dashed", color = "black") + 
  ylab("Vote share") +
  xlab("Election year") + 
  ggtitle("Vote share of main political parties running \nfor President: first ballot (Brazil, 1998-2018)") 

annotation <- data.frame(x = 2015, y = 51, label = "Victory margin on the 1st ballot")  

plot10 <- plot10 + geom_text(data = annotation, aes(x=x, y=y, label=label), color = "black", size = 3, fontface = "italic")

plot10

# 1.2 Eleições para os Executivos Estaduais (Governadores)
# Analisando apenas os seguintes partidos: PT, PSDB, PSL e PMDB 

table_exe_states <- exe_states %>% 
  group_by(election, party) %>% 
  summarise(mean_vote_share = mean(vote_share))

str(table_exe_states)

plot_gov_losers <- table_exe_states %>% 
  filter(party %in% code_losers) %>% 
  ggplot(aes(x = election, y = mean_vote_share, color = party)) + geom_line(size = 1) + geom_point(size = 2) + 
  my_theme + 
  theme(panel.grid = element_blank(), plot.title = element_text(size = 14, face = "bold")) + 
  scale_x_continuous(breaks = c(1998, 2002, 2006, 2010, 2014, 2018)) + 
  scale_y_continuous(limits = c(0, 50), breaks = c(0, 10, 20, 30, 40, 50)) + 
  scale_color_manual(name = "Party", labels = party_losers, values = colors_losers) + 
  ylab("Vote share") +
  xlab("Election year") + 
  ggtitle("Losers") 

plot_gov_losers

plot_gov_winners <- table_exe_states %>% 
  filter(party %in% code_winners) %>% 
  ggplot(aes(x = election, y = mean_vote_share, color = party)) + geom_line(size = 1) + geom_point(size = 2) + 
  my_theme + 
  theme(panel.grid = element_blank(), plot.title = element_text(size = 14, face = "bold")) + 
  scale_x_continuous(breaks = c(1998, 2002, 2006, 2010, 2014, 2018)) + 
  scale_y_continuous(limits = c(0, 50), breaks = c(0, 10, 20, 30, 40, 50)) + 
  scale_color_manual(name = "Party", labels = party_winners, values = colors_winners) + 
  ylab("Vote share") +
  xlab("Election year") + 
  ggtitle("Winners") 

plot_gov_winners

gov_plot <- ggarrange(plot_gov_losers, plot_gov_winners, ncol = 2, nrow = 1)

  
gov_plot <- annotate_figure(gov_plot, top = text_grob("Vote share of main parties running for Governor (Brazil, 1998-2018)", 
                                        color = "black", face = "bold", size = 14))

gov_plot

# 1.3 Eleições para o Legislativo Federal (Deputados Federais)
# Analisando apenas os seguintes partidos: PT, PSDB, PSL, PMDB e PFL/DEM

table_leg_br <- leg_br %>% 
  group_by(election, party) %>% 
  summarise(mean_vote_share = mean(vote_share))

table_leg_br_others <- table_leg_br %>% 
  filter(party %notin% code_party_labels2) %>%  
  group_by(election) %>% 
  summarise(mean_vote_share = sum(mean_vote_share))

table_leg_br_others <- data.frame(table_leg_br_others)
table_leg_br <- data.frame(table_leg_br)
table_leg_br_others[, "party"] <- factor("Others")
table_leg_br_others <- table_leg_br_others[, c(1, 3, 2)]

str(table_leg_br)
str(table_leg_br_others)

table_leg_br_final <- rbind(table_leg_br, table_leg_br_others)

party_labels3 <- c("PFL/DEM", "PMDB", "PSDB", "PSL", "PT", "Others")
lineplot_colors2 <- c("#FF8C00", "#FFD700", "#0000FF", "#808000", "#FF0000", "#FF00FF")

plot11 <- table_leg_br_final %>% 
  filter(party %in% c(code_party_labels2, "Others")) %>% 
  ggplot(aes(x = election, y = mean_vote_share, color = party)) + geom_line(size = 1) + geom_point(size = 2) + 
  my_theme + 
  theme(panel.grid = element_blank(), plot.title = element_text(size = 14, face = "bold")) + 
  scale_x_continuous(breaks = c(1998, 2002, 2006, 2010, 2014, 2018)) + 
  scale_y_continuous(limits = c(0, 70), breaks = c(0, 10, 20, 30, 40, 50, 60, 70)) + 
  scale_color_manual(name = "Party", labels = party_labels3, values = lineplot_colors2) + 
  ylab("Vote share") +
  xlab("Election year") + 
  ggtitle("Vote share of parties running for the Chamber of Deputies (Brazil, 1998-2018)")

plot11

plot12 <- table_leg_br_final %>% 
  filter(party %in% c(code_party_labels2)) %>% 
  ggplot(aes(x = election, y = mean_vote_share, color = party)) + geom_line(size = 1) + geom_point(size = 2) + 
  my_theme + 
  theme(panel.grid = element_blank(), plot.title = element_text(size = 14, face = "bold")) + 
  scale_x_continuous(breaks = c(1998, 2002, 2006, 2010, 2014, 2018)) + 
#  scale_y_continuous(limits = c(0, 30), breaks = c(0, 10, 20, 30)) + 
  scale_color_manual(name = "Party", labels = party_labels2, values = lineplot_colors) + 
  ylab("Vote share") +
  xlab("Election year") + 
  ggtitle("Vote share of the main parties running for the Chamber of Deputies (Brazil, 1998-2018)")

plot12

# 1.4 Eleições para os Legislativos Estaduais (Deputados Estaduais)
# Analisando apenas os seguintes partidos: PT, PSDB, PSL, PMDB e PFL/DEM

table_leg_states <- leg_states %>% 
  group_by(election, party) %>% 
  summarise(mean_vote_share = mean(vote_share))

table_leg_states_others <- table_leg_states %>% 
  filter(party %notin% code_party_labels2) %>%  
  group_by(election) %>% 
  summarise(mean_vote_share = sum(mean_vote_share))

table_leg_states_others <- data.frame(table_leg_states_others)
table_leg_states <- data.frame(table_leg_states)
table_leg_states_others[, "party"] <- factor("Others")
table_leg_states_others <- table_leg_states_others[, c(1, 3, 2)]

str(table_leg_states)
str(table_leg_states_others)

table_leg_states_final <- rbind(table_leg_states, table_leg_states_others)

plot13 <- table_leg_states_final %>% 
  filter(party %in% c(code_party_labels2, "Others")) %>% 
  ggplot(aes(x = election, y = mean_vote_share, color = party)) + geom_line(size = 1) + geom_point(size = 2) + 
  my_theme + 
  theme(panel.grid = element_blank(), plot.title = element_text(size = 14, face = "bold")) + 
  scale_x_continuous(breaks = c(1998, 2002, 2006, 2010, 2014, 2018)) + 
  scale_y_continuous(limits = c(0, 70), breaks = c(0, 10, 20, 30, 40, 50, 60, 70)) + 
  scale_color_manual(name = "Party", labels = party_labels3, values = lineplot_colors2) + 
  ylab("Vote share") +
  xlab("Election year") + 
  ggtitle("Vote share of parties running for State Assemblies (Brazil, 1998-2018)")

plot13

plot14 <- table_leg_states_final %>% 
  filter(party %in% c(code_party_labels2)) %>% 
  ggplot(aes(x = election, y = mean_vote_share, color = party)) + geom_line(size = 1) + geom_point(size = 2) + 
  my_theme + 
  theme(panel.grid = element_blank(), plot.title = element_text(size = 14, face = "bold")) + 
  scale_x_continuous(breaks = c(1998, 2002, 2006, 2010, 2014, 2018)) + 
  scale_y_continuous(limits = c(0, 20), breaks = c(0, 10, 20)) + 
  scale_color_manual(name = "Party", labels = party_labels2, values = lineplot_colors) + 
  ylab("Vote share") +
  xlab("Election year") + 
  ggtitle("Vote share of the main parties running for State Assemblies (Brazil, 1998-2018)")

plot14

# 2.0 Salvando externamente os plots

ggsave("Votação_principais_partidos_presidente.png", plot10, dpi = 1200, height = 7, width = 7 * 1.5)
ggsave("Votação_principais_partidos_governador.png", gov_plot, dpi = 1200, height = 7, width = 7 * 2)
ggsave("Votação_todos_partidos_camara_deputados.png", plot11, dpi = 1200, height = 7, width = 7 * 1.5)
ggsave("Votação_principais_partidos_camara_deputados.png", plot12, dpi = 1200, height = 7, width = 7 * 1.5)
ggsave("Votação_todos_partidos_assembleias_legislativas.png", plot13, dpi = 1200, height = 7, width = 7 * 1.5)
ggsave("Votação_principais_partidos_assembleias_legislativas.png", plot14, dpi = 1200, height = 7, width = 7 * 1.5)
